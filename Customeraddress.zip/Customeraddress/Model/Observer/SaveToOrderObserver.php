<?php
namespace CP\Customeraddress\Model\Observer;

use Magento\Framework\Event\Observer as EventObserver;
use Magento\Framework\Event\ObserverInterface;
use \Magento\Framework\Exception\LocalizedException;

class SaveToOrderObserver implements ObserverInterface
{
     /**
     * @var \Magento\Sales\Api\OrderAddressRepositoryInterface
     */
    protected $orderAddressRepository;
    /**
     * @var \Magento\Sales\Api\OrderRepositoryInterface
     */
    protected $orderRepository;
    protected $_eavAttribute;
    protected $_resource;
    protected $connection = null;
    /**
     * @param \Magento\Sales\Api\OrderAddressRepositoryInterface $orderAddressRepository
     */
    public function __construct(
        \Magento\Sales\Api\OrderAddressRepositoryInterface $orderAddressRepository,
        \Magento\Sales\Api\OrderRepositoryInterface $orderRepository,
        \Magento\Eav\Model\ResourceModel\Entity\Attribute $eavAttribute,
        \Magento\Framework\App\ResourceConnection $resource
    ) { 
        $this->orderAddressRepository = $orderAddressRepository;
        $this->orderRepository = $orderRepository;
        $this->_eavAttribute = $eavAttribute;
        $this->_resource = $resource;
    }
    
    protected function getConnection()
    {
        if (!$this->connection) {
            $this->connection = $this->_resource->getConnection('core_write');
        }
        return $this->connection;
    }
    /**
     * {@inheritdoc}
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function execute(EventObserver $observer)
    {
        try
        {
            /** @var \Magento\Sales\Model\Order $orderInstance */
            $orderInstance = $observer->getEvent()->getOrder();
            /** @var \Magento\Quote\Model\Quote $quoteInstance */
            $quoteInstance = $observer->getEvent()->getQuote();
            $quoteShippingAddress = $quoteInstance->getShippingAddress();
            $quoteBillingAddress = $quoteInstance->getBillingAddress();
            $orderShippingAddress = $orderInstance->getShippingAddress();
            $orderBillingAddress = $orderInstance->getBillingAddress();
            if ($orderShippingAddress !== null && $quoteShippingAddress !== null) {
                $orderShippingAddress->setData(
                    'magento_username',
                    $quoteShippingAddress->getData('magento_username')
                );
            }
       
            $this->orderRepository->save($orderInstance);
            if ($orderShippingAddress !== null) {
                $this->orderAddressRepository->save($orderShippingAddress);
            }
            
            if($quoteShippingAddress->getData('customer_address_id'))
            {
                try {
                    $table = '`'. $this->_resource->getTableName('customer_address_entity_text').'`'; 
                    $attributeId = $this->_eavAttribute->getIdByCode('customer_address', 'magento_username');
                    $entityId = $quoteShippingAddress->getData('customer_address_id');
                    $text = $quoteShippingAddress->getData('magento_username');
                    
                    $sql = "INSERT INTO $table(`attribute_id`, `entity_id`,`value`) VALUES ('$attributeId','$entityId','$text')";
                    $this->getConnection()->query($sql);
                }catch (\Exception $e) { 
                    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/checkoutError.log');
                    $logger = new \Zend\Log\Logger();
                    $logger->addWriter($writer);
                    $logger->info($e->getMessage());
                }
            }
        }catch(\Exception $e)
        {
            throw new LocalizedException(__($e->getMessage()));
        }
    }
}