var config = {
    config: {
        mixins: {
            'Magento_Checkout/js/action/set-shipping-information': {
                'CP_Customeraddress/js/action/set-shipping-information-mixin': true
            }
        }
    }
};